clc;
clear;

load cascade_pathway_block_t;
load cascade_pathway_block_x1;
load cascade_pathway_block_x2;
load cascade_pathway_block_x3;

plot(t,x1);
hold on;
plot(t,x2);
hold on;
plot(t,x3);

xlabel('$T/s$','interpreter','latex', 'FontSize', 12);
legend('x_{1}','x_{2}','x_{3}')