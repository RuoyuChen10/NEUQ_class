clc;
clear;

load disturbance_cpb_t;
load disturbance_cpb_x1;
load disturbance_cpb_x2;
load disturbance_cpb_x3;

plot(t,x1);
hold on;
plot(t,x2);
hold on;
plot(t,x3);

xlabel('$T/s$','interpreter','latex', 'FontSize', 12);
legend('x_{1}','x_{2}','x_{3}')