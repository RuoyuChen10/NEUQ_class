clc;
clear;

load disturbance_sgn_t;
load disturbance_sgn_x1;
load disturbance_sgn_x2;
load disturbance_sgn_x3;
load disturbance_sgn_x4;
load disturbance_sgn_x5;

plot(t,x1);
hold on;
plot(t,x2);
hold on;
plot(t,x3);
hold on;
plot(t,x4);
hold on;
plot(t,x5);

xlabel('$T/s$','interpreter','latex', 'FontSize', 12);
legend('x_{1}','x_{2}','x_{3}','x_{4}','x_{5}')