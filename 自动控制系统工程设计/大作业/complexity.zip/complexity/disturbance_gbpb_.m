clc;
clear;

load disturbance_gbpb_t;
load disturbance_gbpb_x1;
load disturbance_gbpb_x2;
load disturbance_gbpb_x3;
load disturbance_gbpb_x4;

plot(t,x1);
hold on;
plot(t,x2);
hold on;
plot(t,x3);
hold on;
plot(t,x4);

xlabel('$T/s$','interpreter','latex', 'FontSize', 12);
legend('x_{1}','x_{2}','x_{3}','x_{4}')