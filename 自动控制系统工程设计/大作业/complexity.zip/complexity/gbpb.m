clc;
clear;

load gbpb_t;
load gbpb_x1;
load gbpb_x2;
load gbpb_x3;
load gbpb_x4;

plot(t,x1);
hold on;
plot(t,x2);
hold on;
plot(t,x3);
hold on;
plot(t,x4);

xlabel('$T/s$','interpreter','latex', 'FontSize', 12);
legend('x_{1}','x_{2}','x_{3}','x_{4}')