import java.io.*;
public class Test2 {
	public static void main(String[] args) throws IOException {
		int i=0;
		//********Found**************
		______________ fin=null;
		try{
			//********Found**********
			fin=new FileInputStream (_________);
			//********Found***********
		}_________(Exception e){
			System.out.println("Open File Error");
			};
		do{
			i=fin.read();//Read one byte			
			if(i!=-1){
				System.out.print((char)i);
			}
		}while(i!=-1);
		//**********Found*************
		fin._________();//Close the open file
	}
}

