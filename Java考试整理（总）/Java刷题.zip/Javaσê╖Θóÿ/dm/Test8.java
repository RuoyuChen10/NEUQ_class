import java.awt.*;
import java.awt.event.*;

public class Test8 extends Frame {
	public Test8(String s) { // ��дJava_2�Ĺ��캯���������ø���Frame�Ĺ��캯��
		//**********Found***********
		_________;
	}

	public static void main(String args[]) {
		Test8 fr = new Test8("Testing");
		Button b = new Button("Please press me!");
		// *********Found********
		______________(new HandleButton());//��ťbע���¼�
		fr.add(b);
		fr.pack();

		// *********Found********
		fr.___________(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		//********Found**********
		___________;//���ô���fr�ɼ�
	}
}

class HandleButton implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		System.out.println("The button is pressed!");
	}
}
