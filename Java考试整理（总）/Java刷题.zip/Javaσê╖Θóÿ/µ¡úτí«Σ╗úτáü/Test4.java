import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
public class Test4 extends Applet implements ActionListener{
	TextField in1,in2;
	Button btn;
	int a=0, b=0, max;	
	public void init(){
		in1=new TextField(5);
		in2=new TextField(5);
		btn=new Button("�Ƚ�");
		add(in1);
		add(in2);
		add(btn);
		//********Found*************
		btn.addActionListener(this);
	}
		
	public void actionPerformed(ActionEvent e)
	{
        //*********Found********
		a=Integer.parseInt(in1.getText());
        //*********Found********
		b=Integer.parseInt(in2.getText());
		if (a>b)
			max=a;
		else
			max=b;			
        //*********Found********
		btn.setLabel("�����������ֵ�ǣ�"+max);
	}
}

