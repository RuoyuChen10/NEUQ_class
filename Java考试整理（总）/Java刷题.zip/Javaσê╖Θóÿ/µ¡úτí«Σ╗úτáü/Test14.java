import java.applet.Applet;
import java.awt.Graphics;

//**********Found************
public class Test14 extends Applet{
	//***********Found******************
	public void paint(Graphics g) {
		for(int row=1;row<=7;row++){
			//**********Found**********
			int x=220-20*row;int y=20+20*row;
			for(int column=1;column<2*row-1;column++)
				//*********Found***********
				g.drawString("*", x+20*(column-1), y);
		}
	}
}

