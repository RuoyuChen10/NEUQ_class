
public class Test16 {
	public static void main(String[] args) {
		//*********Found*********
		int x[]=__________[5];
		int i=0,j=0,t;
		for(i=0;i<5;i++){
			//*******Found*********
			x[i]=(int)(_________()*100) + 1;
		}
		System.out.println("����֮ǰ����Ϊ��");
		for(i=0;i<5;i++){
			System.out.print(x[i]+ ",");
		}
		for(i=0;i<5;i++){
			//*********Found**********
			for(j=0;j<______;j++){
				//********Found************	
				if(x[j]<x[______]){
					t=x[j];x[j]=x[j+1];x[j+1]=t;
				}
			}
		}
		System.out.println("\n����֮�����Ϊ��");
		for(i=0;i<5;i++){
			System.out.print(x[i]+ ",");
		}
	}
}

