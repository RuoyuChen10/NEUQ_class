import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
//*********Found************
class WinVarial ____________{//�̳и���JFrame
	JTextField text;
	TextListener listener;
	//********Found*************
	_______________(){//�����޲����Ĺ��캯��
		init();
		this.setBounds(100, 100, 150, 150);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	void init(){
		this.setLayout(new FlowLayout());
		text=new JTextField(10);
		listener=new TextListener();
		//*********Found***************
		text.____________(listener);//�ı���ע������¼�
		this.add(text);//���ı������ӵ�������
	}
	
}

//***********Found*****************
class TextListener ___________ ActionListener{

	public void actionPerformed(ActionEvent e) {
		int n=0,m=0;
		String str=e.getActionCommand();
		try{
			n=Integer.parseInt(str);
			m=n*n;
			System.out.println(n+"��ƽ���ǣ�" + m);
		}
		//************Found**************
		_________(Exception ee){
			System.out.println(ee.toString());
		}
		
	}
	
}

public class Test27 {
	
	public static void main(String[] args) {
		new WinVarial();

	}
}


