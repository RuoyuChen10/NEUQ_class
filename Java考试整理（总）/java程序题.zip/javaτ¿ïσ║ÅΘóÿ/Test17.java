
public class Test17 {

	public static void main(String[] args) {
		//*********Found**********
		int _____ x=new int[9][];
		int i=0,j=0;
		//********Found**********
		for(i=0;i<x._______ ;i=i+1){
			//********Found*********
			x[i]=_______ int[i+1];
		}
		for(i=0;i<x.length ;i++ ){
			for(j=0;j<x[i].length ;j++){
				//**********Found*************
				x______=(i+1)*(j+1);
				System.out.print((i+1) + "X" + (j+1) + "=" + x[i][j] + " ");
			}
			System.out.println();//��ӡ����
		}
	}
}

