import java.awt.*;
import java.io.*;
import javax.swing.*;
public class Test3 {
	public static void main(String[] args) throws IOException {
		int i=0;
		//********Found**************
		FileInputStream _______=null;
		JFileChooser jf =new JFileChooser();
		jf.setCurrentDirectory(new File("."));
		int x=jf.showDialog(null, "��");
        String filename = jf.getSelectedFile().getAbsolutePath();
       	try{
			//********Found**********
			fin=new FileInputStream (________);
		}catch(Exception e){
			System.out.println("Open File Error");
			};
		do{
			i=fin.read();//Read one byte			
			if(i!=-1){
				System.out.print((char)i);
			}
		//**********Found**********
		}while(________);
		//**********Found*************
		fin._________();//Close the open file
	}
}
