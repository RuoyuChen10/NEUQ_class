import java.text.DecimalFormat;
//**********Found*************
__________ Shape{ //����ӿ�Shape
	public abstract double area();
}

//***********Found*************
class Circle ____________ Shape{//������Circleʵ�ֽӿ�Shape
	protected double radius;
	//*********Found***************
	public __________(){ //������Circle�Ĺ��캯��
		setRadius(0);
	}
	
	public Circle(double r){
		radius=r;
	}
	public void setRadius(double r){
		this.radius=(r>=0?r:0);
	}
	public double getRadius(){
		return this.radius;
	}

	public double area() {
		return Math.PI*radius;
	}
	
}

class Triangle implements Shape{
	//**********Found**************
	________ double x,y;//���屣���ĳ�Ա����x,y������Ϊdouble
	public Triangle(){
		setxy(0,0);
	}
	
	public Triangle(double a,double b){
		setxy(a,b);
	}
	
	public void setxy(double x,double y){
		this.x=x;
		this.y=y;
	}
	
	public double getx(){
		return x;
	}
	
	public double gety(){
		return y;
	}
	

	public double area() {
		return x*y/2;
	}
	
}

public class Test23 {	
	public static void main(String[] args) {
		Circle c=new Circle(7); 
		Triangle t=new Triangle(3,4);
		String output="";
		DecimalFormat p2=new DecimalFormat("0.00");
		output+="\n �뾶Ϊ" + c.getRadius() + "Բ�������" + p2.format(c.area());
		output+="\n ��Ϊ" + t.getx() + "��Ϊ" + t.gety() + "�������������" + p2.format(t.area());
		System.out.println(output);
	}

}

