import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test28 extends JFrame implements ActionListener,ItemListener{

	JTextArea output;
	JScrollPane sp;
	String nl="\n";
	public Test28(){
		JMenuBar mnb;
		JMenu mn;
		JMenuItem mni;
		JRadioButtonMenuItem rbmni;
		JCheckBoxMenuItem cbmni;
		this.addWindowListener(new WindowAdapter (){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		Container c=this.getContentPane();
		output =new JTextArea(6,20);
		sp=new JScrollPane(output);//�ı������зŹ�����
		c.add(sp,BorderLayout.CENTER);
		//******Found*********
		mnb=new _________();//����˵���
		this.setJMenuBar(mnb);
		mn=new JMenu("�ļ�");
		//*********Found**********
		mnb.add(___);//�˵����м����ļ��˵�
		mni=new JMenuItem("�ر�");
		//**********Found**************
		mn.add(____);//�˵��м���˵���
		mni.addActionListener(this);
		//************Found*****************
		mn._______();//�˵��м���ָ���
		ButtonGroup gp=new ButtonGroup();//���尴ť��
		rbmni=new JRadioButtonMenuItem("��ѡ��ť�˵�1");
		gp.add(rbmni);
		rbmni.addActionListener(this);
		mn.add(rbmni);
		
	}	
	
	public static void main(String[] args) {
		Test28 f=new Test28();
		f.setTitle("�˵���ʾ");
		f.setVisible(true);
		f.setSize(400,200);

	}

	public void itemStateChanged(ItemEvent e) {
		JMenuItem source =(JMenuItem)(e.getSource());
		String s=nl+"" + source.getText();
		output.append(s+"\n");	
		
	}

	public void actionPerformed(ActionEvent e) {
		JMenuItem source =(JMenuItem)(e.getSource());
		String s="\n" + source.getText();
		output.append(s+"\n");		
	}

}

