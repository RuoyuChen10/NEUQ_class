import java.io.*;
public class Test7 {
    //**************Found****************
	public static void main(String[] args) _________ IOException {
		//***********Found**************
		InputStreamReader reader=new InputStreamReader(__________);
		//**********Found****************
		BufferedReader in=new _________(reader);
		System.out.print("������ѧУ����:");
		//*********Found**************
		String name=in.__________();
		System.out.println(name);

	}

}

