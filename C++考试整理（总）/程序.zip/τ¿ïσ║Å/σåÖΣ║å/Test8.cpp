#include <iostream>
#include <cstring>
using namespace std;
void myStrCat(char *dst, char *src);//��1��______  //myStrCat����������
int main() {        
    char dst[100]="Hello, ";//��2��______ dst[100]="Hello, ";
    char src[100]="Good luck!";
    myStrCat(dst, src);
    cout << dst << endl;
    return 0;
}
    void myStrCat(char *dst, char *src) {//��3��______ myStrCat(char *dst, char *src) {
    int i=0, len;
    len = strlen(dst);
while(src[i]) {
    dst[len] = src[i]; //��4��______ = src[i];
    len++;
    i++;
}
    dst[len] = '\0';
}

