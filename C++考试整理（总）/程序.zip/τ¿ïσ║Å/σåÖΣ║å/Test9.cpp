#include<iostream>
using namespace std;
double max(double a, double b, double c) {//��1��______ max(double a, double b, double c) {
	if(a>b&&a>c) return a;
	if(b>a&&b>c) return b;//if(��2��______) return b;
	return c;//return ��3��______;
}
int main() {
  cout<<max(3.2,7.4,4.5)<<endl;//��4��______<<max(3.2,7.4,4.5)<<endl;
    return 0;
}

