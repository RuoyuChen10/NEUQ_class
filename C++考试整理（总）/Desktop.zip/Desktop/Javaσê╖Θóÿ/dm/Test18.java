
public class Test18 {

	private String name;
	private String sex;
	private int age;
	//*******Found***********
	Test18(________ name){
		setName(name);
	}
	Test18(String name,String sex,int age){
		setName(name);
		setSex(sex);
		setAge(age);
	}
	public void setName(String name){
		//**********Found**********
		________.name =name;
	}
	public void setSex(String sex){
		this.sex=sex;
	}
	public void setAge(int age){
		this.age =age;
	}
	public String getName(){
		return name;
	}
	public String getSex(){
		//**********Found*************
		return _______;
	}
	public int getAge(){
		return age;
	}	
	public static void main(String[] args) {
		Test18 p1=new Test18("Z3","Men",28);
		Test18 p2=new Test18("L4");
		p2.setSex("Wormen");
		//*******Found***********//
		p2.________(20);
		System.out.println("��1���ˣ�����:"+p1.getName()+",�Ա�:" + p1.getSex()+",����:"+ p1.getAge());
		System.out.println("��2���ˣ�����:"+p2.getName()+",�Ա�:" + p2.getSex()+",����:"+ p2.getAge());
	}
}

